package com.calleridentifier.supabase

import kotlinx.serialization.Serializable

@Serializable
data class ClienteEntity(
    val id: Int? = null,
    val tel: String? = null,
    val nome: String? = null,
    val modello: String? = null,
    val garanzia: String? = null,
    // Aggiungiamo i campi che esistono ma non usiamo per evitare errori
    val cfiscale: String? = null,
    val indirizzo: String? = null,
    val città: String? = null,
    val punz: String? = null,
    val pr: String? = null,
    val esitovp: String? = null,
    val ultimavp: String? = null,
    val mat: String? = null,
    val fax: String? = null,
    val installazione: String? = null,
    val pagamento: String? = null,
    val scadenza: String? = null,
    val importo: String? = null,
    val iva20: String? = null,
    val totale: String? = null,
    val info: String? = null,
    val piva: String? = null,
    val entrate: String? = null,
    val intervento: String? = null,
    val scadenzavp: String? = null,
    val passaggio: String? = null,
    val primafisca: String? = null,
    val dataultimavp: String? = null,
    val controllovp: String? = null,
    val software: String? = null,
    val softwarecontratto: String? = null,
    val softwareimporto: String? = null,
    val softwarescadenza: String? = null,
    val email: String? = null,
    val kitrt: String? = null,
    val datart: String? = null,
    val comm: String? = null,
    val sedelegale: String? = null,
    val xml7: String? = null,
    val lotteria: String? = null,
    val modellort: String? = null
)