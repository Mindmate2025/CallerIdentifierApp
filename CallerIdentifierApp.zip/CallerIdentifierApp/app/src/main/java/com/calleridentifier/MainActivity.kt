package com.calleridentifier

import android.Manifest
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.calleridentifier.database.AppDatabase
import com.calleridentifier.database.toLocalEntity
import com.calleridentifier.supabase.SupabaseService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var tvStatus: TextView
    private lateinit var btnToggleService: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvStatus = findViewById(R.id.tvStatus)
        btnToggleService = findViewById(R.id.btnToggleService)

        setupUI()
        updateStatus()
        updateToggleButton()
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
        updateToggleButton()
    }

    private fun setupUI() {
        findViewById<Button>(R.id.btnRequestPermissions).setOnClickListener {
            requestAllPermissions()
        }

        findViewById<Button>(R.id.btnOverlayPermission).setOnClickListener {
            requestOverlayPermission()
        }

        findViewById<Button>(R.id.btnSetDefaultDialer).setOnClickListener {
            requestCallScreeningRole()
        }

        findViewById<Button>(R.id.btnAddTestContacts).setOnClickListener {
            syncDatabase()
        }

        // Pulsante unico: Riprendi/Sospendi
        btnToggleService.setOnClickListener {
            if (PersistentService.isRunning) {
                // ⏸️ Sospendi
                stopService(Intent(this, PersistentService::class.java))
                PersistentService.isRunning = false
                showToast("Modalità background disattivata")
            } else {
                // ▶️ Riprendi + minimizza app
                ensurePersistentService()
                requestIgnoreBatteryOptimizations()
                showToast("Modalità background attivata")
                val moved = moveTaskToBack(true)
                if (!moved) {
                    val i = Intent(Intent.ACTION_MAIN).apply {
                        addCategory(Intent.CATEGORY_HOME)
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    startActivity(i)
                }
            }
            updateStatus()
            updateToggleButton()
        }
    }

    private fun updateToggleButton() {
        if (PersistentService.isRunning) {
            btnToggleService.text = "⏸️ Sospendi (ferma background)"
            btnToggleService.backgroundTintList =
                ContextCompat.getColorStateList(this, R.color.state_neutral)
            btnToggleService.setTextColor(
                ContextCompat.getColor(this, R.color.brand_on_primary)
            )
        } else {
            btnToggleService.text = "▶️ Riprendi (resta in background)"
            btnToggleService.backgroundTintList =
                ContextCompat.getColorStateList(this, R.color.brand_accent)
            btnToggleService.setTextColor(
                ContextCompat.getColor(this, R.color.text_primary)
            )
        }
    }

    private fun requestAllPermissions() {
        val permissionsToRequest = mutableListOf(
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.READ_CALL_LOG
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissionsToRequest.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        ActivityCompat.requestPermissions(this, permissionsToRequest.toTypedArray(), 100)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100) {
            updateStatus()
            showToast("Permessi aggiornati")
        }
    }

    private fun requestOverlayPermission() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        } else {
            showToast("Permesso overlay già concesso")
        }
    }

    private fun requestCallScreeningRole() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val roleManager = getSystemService(Context.ROLE_SERVICE) as RoleManager
            if (!roleManager.isRoleHeld(RoleManager.ROLE_CALL_SCREENING)) {
                val intent = roleManager.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING)
                startActivityForResult(intent, 2)
            } else {
                showToast("Ruolo Call Screening già attivo")
            }
        } else {
            showToast("Questa funzione richiede Android 10 o superiore")
        }
    }

    private fun syncDatabase() {
        val progressDialog = AlertDialog.Builder(this)
            .setTitle("Connessione a Supabase…")
            .setMessage("Download e aggiornamento clienti in corso…")
            .setCancelable(false)
            .create()
        progressDialog.show()

        lifecycleScope.launch {
            var downloaded = -1
            var localCount = -1
            var errorMsg: String? = null

            try {
                downloaded = withContext(Dispatchers.IO) {
                    val supabaseService = SupabaseService()
                    val clientiRemoti = supabaseService.getAllClienti()
                    val clientiLocali = clientiRemoti.map { it.toLocalEntity() }
                    val db = AppDatabase.getDatabase(applicationContext)
                    db.clienteDao().insertAllClienti(clientiLocali)
                    clientiLocali.size
                }
                localCount = withContext(Dispatchers.IO) {
                    AppDatabase.getDatabase(applicationContext).clienteDao().getClientCount()
                }
            } catch (e: Exception) {
                errorMsg = e.message
            } finally {
                progressDialog.dismiss()
            }

            if (errorMsg != null) {
                showToast("Errore sync: $errorMsg")
            } else {
                val base = "Sync completata: $downloaded record scaricati."
                val extra = "  Clienti locali: $localCount"
                showToast(base + extra)
                val overlayStatus =
                    if (Settings.canDrawOverlays(this@MainActivity)) "✅ Overlay OK" else "❌ Overlay mancante"
                val serviceStatus =
                    if (PersistentService.isRunning) "✅ Servizio attivo" else "⏸️ Servizio non attivo"
                val dbStatus = "Clienti locali: $localCount"
                tvStatus.text =
                    "Permessi: ${getPhonePermissionStatus()}\nOverlay: $overlayStatus\nServizio: $serviceStatus\n$dbStatus"
            }
        }
    }

    private fun updateStatus() {
        val overlayStatus =
            if (Settings.canDrawOverlays(this)) "✅ Overlay OK" else "❌ Overlay mancante"
        val serviceStatus =
            if (PersistentService.isRunning) "✅ Servizio attivo" else "⏸️ Servizio non attivo"
        tvStatus.text =
            "Permessi: ${getPhonePermissionStatus()}\nOverlay: $overlayStatus\nServizio: $serviceStatus"
    }

    private fun getPhonePermissionStatus(): String {
        val granted = ContextCompat.checkSelfPermission(
            this, Manifest.permission.READ_PHONE_STATE
        ) == android.content.pm.PackageManager.PERMISSION_GRANTED
        return if (granted) "✅ OK" else "❌ Mancanti"
    }

    private fun showToast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    private fun ensurePersistentService() {
        val intent = Intent(this, PersistentService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            ContextCompat.startForegroundService(this, intent)
        } else {
            startService(intent)
        }
    }

    private fun requestIgnoreBatteryOptimizations() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                    data = Uri.parse("package:$packageName")
                }
                startActivity(intent)
            }
        }
    }
}
