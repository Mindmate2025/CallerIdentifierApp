package com.calleridentifier.supabase

import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.postgrest.Postgrest

object SupabaseClient {
    val client = createSupabaseClient(
        supabaseUrl = "https://zglulbytospjuhrorxzl.supabase.co",
        supabaseKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InpnbHVsYnl0b3NwanVocm9yeHpsIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTM1MzYxNjEsImV4cCI6MjA2OTExMjE2MX0.Sp4V0yQ3Wizqya4iegsm7ynBae8WdOAuuxkkQ7UluYI"
    ) {
        install(Postgrest)
    }
}