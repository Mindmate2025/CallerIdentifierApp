package com.calleridentifier.supabase

import android.util.Log
import io.github.jan.supabase.postgrest.from
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class SupabaseService {
    
    private val supabase = SupabaseClient.client
    
    suspend fun testConnection(): Boolean {
        return try {
            Log.d("SupabaseService", "🔍 Test connessione Supabase...")
            
            val result = supabase
                .from("clienti")
                .select {
                    // Seleziona solo i campi necessari
                }
                .decodeList<ClienteEntity>()
            
            Log.d("SupabaseService", "✅ Connessione OK - ${result.size} clienti trovati")
            
            // Debug: mostra primi 3 clienti
            for (i in 0 until minOf(3, result.size)) {
                val cliente = result[i]
                Log.d("SupabaseService", "Cliente: ${cliente.nome} - Tel: ${cliente.tel} - Modello: ${cliente.modello}")
            }
            
            true
        } catch (e: Exception) {
            Log.e("SupabaseService", "❌ ERRORE:")
            Log.e("SupabaseService", "Messaggio: ${e.message}")
            e.printStackTrace()
            false
        }
    }
    
    suspend fun findClienteByTelefono(telefono: String): ClienteEntity? {
        return withContext(Dispatchers.IO) {
            try {
                Log.d("SupabaseService", "Cerco cliente con telefono: $telefono")
                
                val numeroTelefono = pulisciNumero(telefono)
                Log.d("SupabaseService", "Numero pulito: $numeroTelefono")
                
                val result = supabase
                    .from("clienti")
                    .select {
                        // Seleziona solo i campi necessari
                    }
                    .decodeList<ClienteEntity>()
                
                Log.d("SupabaseService", "Trovati ${result.size} clienti nel database")
                
                // Filtra manualmente per trovare il numero (campo "tel")
                val cliente = result.find { cliente ->
                    val telefonoCliente = pulisciNumero(cliente.tel ?: "")
                    Log.d("SupabaseService", "Confronto: '$numeroTelefono' con '$telefonoCliente'")
                    
                    telefonoCliente == numeroTelefono ||
                    telefonoCliente == numeroTelefono.removePrefix("39") ||
                    numeroTelefono == telefonoCliente.removePrefix("39") ||
                    numeroTelefono.takeLast(9) == telefonoCliente.takeLast(9)
                }
                
                if (cliente != null) {
                    Log.d("SupabaseService", "✅ Cliente trovato: ${cliente.nome} - ${cliente.modello} - ${cliente.garanzia}")
                } else {
                    Log.d("SupabaseService", "❌ Nessun cliente trovato per: $numeroTelefono")
                    // Debug: mostra primi 5 numeri nel database
                    for (i in 0 until minOf(5, result.size)) {
                        val c = result[i]
                        Log.d("SupabaseService", "DB: ${c.tel} -> ${c.nome}")
                    }
                }
                
                cliente
                
            } catch (e: Exception) {
                Log.e("SupabaseService", "Errore ricerca cliente: ${e.message}", e)
                null
            }
        }
    }
    
    suspend fun getAllClienti(): List<ClienteEntity> {
        return withContext(Dispatchers.IO) {
            try {
                Log.d("SupabaseService", "Recupero tutti i clienti...")
                
                val result = supabase
                    .from("clienti")
                    .select {
                        // Seleziona solo i campi necessari
                    }
                    .decodeList<ClienteEntity>()
                
                Log.d("SupabaseService", "✅ Recuperati ${result.size} clienti")
                result
                
            } catch (e: Exception) {
                Log.e("SupabaseService", "Errore recupero clienti: ${e.message}", e)
                emptyList()
            }
        }
    }
    
    private fun pulisciNumero(numero: String): String {
        return numero.replace("+", "")
            .replace(" ", "")
            .replace("-", "")
            .replace("(", "")
            .replace(")", "")
    }
}