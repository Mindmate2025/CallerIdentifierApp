package com.calleridentifier

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.TelephonyManager
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import com.calleridentifier.service.HybridClienteService

class CallReceiver : BroadcastReceiver() {
    
    private val receiverScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    
    override fun onReceive(context: Context, intent: Intent) {
        try {
            Log.d("CallReceiver", "Broadcast ricevuto: ${intent.action}")
            
            // Verifica lo stato della chiamata
            val state = intent.getStringExtra(TelephonyManager.EXTRA_STATE)
            
            when (state) {
                TelephonyManager.EXTRA_STATE_RINGING -> {
                    val phoneNumber = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)
                    Log.d("CallReceiver", "CHIAMATA IN ARRIVO da: $phoneNumber")
                    
                    if (!phoneNumber.isNullOrEmpty()) {
                        handleIncomingCall(context, phoneNumber)
                    }
                }
                
                TelephonyManager.EXTRA_STATE_IDLE -> {
                    Log.d("CallReceiver", "Chiamata terminata - Chiusura overlay")
                    stopOverlayService(context)
                }
                
                TelephonyManager.EXTRA_STATE_OFFHOOK -> {
                    Log.d("CallReceiver", "Chiamata risposta")
                }
            }
        } catch (e: Exception) {
            Log.e("CallReceiver", "Errore in onReceive: ${e.message}", e)
        }
    }
    
    private fun handleIncomingCall(context: Context, phoneNumber: String) {
        receiverScope.launch {
            try {
                Log.d("CallReceiver", "Ricerca IBRIDA per: $phoneNumber")
                
                val hybridService = HybridClienteService(context)
                val cliente = hybridService.findClienteByTelefono(phoneNumber)
                
                if (cliente != null) {
                    Log.d("CallReceiver", "Cliente trovato: ${cliente.nome}")
                    startOverlayService(context, phoneNumber, cliente.nome, cliente.modello, cliente.garanzia)
                } else {
                    Log.d("CallReceiver", "Numero sconosciuto")
                    startOverlayService(context, phoneNumber, "Numero Sconosciuto", "", "")
                }
            } catch (e: Exception) {
                Log.e("CallReceiver", "Errore ricerca cliente: ${e.message}", e)
                startOverlayService(context, phoneNumber, "Errore ricerca", "", "")
            }
        }
    }
    
    private fun startOverlayService(
        context: Context,
        phoneNumber: String,
        name: String,
        model: String,
        warranty: String
    ) {
        try {
            Log.d("CallReceiver", "Avvio OverlayService")
            
            val overlayIntent = Intent(context, OverlayService::class.java).apply {
                putExtra("phone_number", phoneNumber)
                putExtra("caller_name", name)
                putExtra("caller_model", model)
                putExtra("caller_warranty", warranty)
            }
            
            context.startService(overlayIntent)
            Log.d("CallReceiver", "OverlayService avviato")
            
        } catch (e: Exception) {
            Log.e("CallReceiver", "Errore avvio overlay: ${e.message}", e)
        }
    }
    
    private fun stopOverlayService(context: Context) {
        try {
            val overlayIntent = Intent(context, OverlayService::class.java)
            context.stopService(overlayIntent)
            Log.d("CallReceiver", "OverlayService fermato")
        } catch (e: Exception) {
            Log.e("CallReceiver", "Errore stop overlay: ${e.message}")
        }
    }
}