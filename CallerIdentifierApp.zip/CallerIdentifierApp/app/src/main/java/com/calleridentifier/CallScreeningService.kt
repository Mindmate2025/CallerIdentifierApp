package com.calleridentifier

import android.telecom.Call
import android.telecom.CallScreeningService
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import com.calleridentifier.service.HybridClienteService

class CallScreeningService : CallScreeningService() {
    
    private val serviceScope = CoroutineScope(Dispatchers.IO)
    
    override fun onScreenCall(callDetails: Call.Details) {
        val phoneNumber = callDetails.handle?.schemeSpecificPart
        
        Log.d("CallScreening", "=== CHIAMATA IN ARRIVO ===")
        Log.d("CallScreening", "Numero: $phoneNumber")
        
        if (phoneNumber != null) {
            serviceScope.launch {
                handleIncomingCall(phoneNumber)
            }
        }
        
        // Rispondi con azione di screening - NON bloccare la chiamata
        val response = CallResponse.Builder()
            .setDisallowCall(false)     // Non bloccare
            .setRejectCall(false)       // Non rifiutare
            .setSkipCallLog(false)      // Non saltare call log
            .setSkipNotification(false) // Non saltare notifiche
            .build()
            
        respondToCall(callDetails, response)
        Log.d("CallScreening", "Risposta inviata: chiamata consentita")
    }
    
    private suspend fun handleIncomingCall(phoneNumber: String) {
        try {
            Log.d("CallScreening", "🔍 Ricerca IBRIDA per: '$phoneNumber'")
            
            val hybridService = HybridClienteService(applicationContext)
            
            // Ricerca ibrida: prima locale (veloce), poi online se necessario
            val cliente = hybridService.findClienteByTelefono(phoneNumber)
            
            if (cliente != null) {
                Log.d("CallScreening", "✅ Cliente trovato: ${cliente.nome} - ${cliente.modello}")
                
                // Avvia overlay con informazioni cliente
                startOverlayService(
                    nome = cliente.nome,
                    modello = cliente.modello, 
                    telefono = phoneNumber,
                    garanzia = cliente.garanzia,
                    isKnownContact = true
                )
                
            } else {
                Log.d("CallScreening", "❌ Cliente NON trovato - numero sconosciuto")
                
                // Numero sconosciuto
                startOverlayService(
                    nome = "Numero Sconosciuto",
                    modello = "",
                    telefono = phoneNumber,
                    garanzia = "",
                    isKnownContact = false
                )
            }
            
        } catch (e: Exception) {
            Log.e("CallScreening", "Errore durante ricerca cliente: ${e.message}", e)
            
            // In caso di errore, mostra overlay generico
            startOverlayService(
                nome = "Errore ricerca",
                modello = "",
                telefono = phoneNumber,
                garanzia = "",
                isKnownContact = false
            )
        }
    }
    
    private fun startOverlayService(nome: String, modello: String, telefono: String, garanzia: String, isKnownContact: Boolean) {
        try {
            Log.d("CallScreening", "Avvio overlay per: $nome")
            
            val intent = android.content.Intent(this, OverlayService::class.java).apply {
                putExtra("caller_name", nome)
                putExtra("caller_company", modello)
                putExtra("caller_number", telefono)
                putExtra("caller_garanzia", garanzia)
                putExtra("is_known", isKnownContact)
            }
            
            startService(intent)
            Log.d("CallScreening", "Overlay service avviato")
            
        } catch (e: Exception) {
            Log.e("CallScreening", "Errore avvio overlay: ${e.message}", e)
        }
    }
}