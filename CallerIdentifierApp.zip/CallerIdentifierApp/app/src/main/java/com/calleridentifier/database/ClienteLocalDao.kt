package com.calleridentifier.database

import androidx.room.*

@Dao
interface ClienteLocalDao {
    
    // Ricerca veloce per numero di telefono
    @Query("""
        SELECT * FROM clienti_locali 
        WHERE tel LIKE '%' || :phoneNumber || '%'
        OR tel LIKE '%' || SUBSTR(:phoneNumber, -9) || '%'
        OR SUBSTR(tel, -9) = SUBSTR(:phoneNumber, -9)
        LIMIT 1
    """)
    suspend fun findByPhoneNumber(phoneNumber: String): ClienteLocalEntity?
    
    // Inserisci o aggiorna cliente
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCliente(cliente: ClienteLocalEntity)
    
    // Inserisci lista clienti (per sincronizzazione)
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllClienti(clienti: List<ClienteLocalEntity>)
    
    // Conta clienti nel database
    @Query("SELECT COUNT(*) FROM clienti_locali")
    suspend fun getClientCount(): Int
    
    // Ottieni tutti i clienti
    @Query("SELECT * FROM clienti_locali ORDER BY nome ASC")
    suspend fun getAllClienti(): List<ClienteLocalEntity>
    
    // Cancella tutti i clienti (per risincronizzazione completa)
    @Query("DELETE FROM clienti_locali")
    suspend fun deleteAll()
    
    // Ottieni timestamp ultima sincronizzazione
    @Query("SELECT MAX(lastSync) FROM clienti_locali")
    suspend fun getLastSyncTime(): Long?
    
    // Ricerca per nome (per debug/testing)
    @Query("SELECT * FROM clienti_locali WHERE nome LIKE '%' || :name || '%'")
    suspend fun findByName(name: String): List<ClienteLocalEntity>
}