package com.calleridentifier.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "clienti_locali")
data class ClienteLocalEntity(
    @PrimaryKey
    val id: Int,
    val tel: String,
    val nome: String,
    val modello: String,
    val garanzia: String,
    val lastSync: Long = System.currentTimeMillis() // Timestamp ultima sincronizzazione
)

// Funzione di conversione da Supabase a Room
fun com.calleridentifier.supabase.ClienteEntity.toLocalEntity(): ClienteLocalEntity {
    return ClienteLocalEntity(
        id = this.id ?: 0,
        tel = this.tel ?: "",
        nome = this.nome ?: "",
        modello = this.modello ?: "",
        garanzia = this.garanzia ?: ""
    )
}