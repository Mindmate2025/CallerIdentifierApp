package com.calleridentifier

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.TextView

class OverlayService : Service() {
    
    private var overlayView: View? = null
    private var windowManager: WindowManager? = null
    
    override fun onCreate() {
        super.onCreate()
        Log.d("OverlayService", "Servizio Overlay creato")
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
    }
    
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.d("OverlayService", "onStartCommand chiamato")
        
        intent?.let {
            val phoneNumber = it.getStringExtra("phone_number") ?: "Sconosciuto"
            val callerName = it.getStringExtra("caller_name") ?: "Numero non registrato"
            val callerModel = it.getStringExtra("caller_model") ?: ""
            val callerWarranty = it.getStringExtra("caller_warranty") ?: ""
            
            Log.d("OverlayService", "Mostra overlay per: $callerName ($phoneNumber)")
            showOverlay(phoneNumber, callerName, callerModel, callerWarranty)
        }
        
        return START_NOT_STICKY
    }
    
    private fun showOverlay(phoneNumber: String, callerName: String, model: String, warranty: String) {
        try {
            // Rimuovi overlay esistente se presente
            removeOverlay()
            
            // Infla il layout dell'overlay
            overlayView = LayoutInflater.from(this).inflate(R.layout.overlay_caller_info, null)
            
            // Imposta i dati del chiamante
            overlayView?.apply {
                findViewById<TextView>(R.id.tvCallerName)?.text = callerName
                findViewById<TextView>(R.id.tvPhoneNumber)?.text = phoneNumber
                findViewById<TextView>(R.id.tvModel)?.text = if (model.isNotEmpty()) "Modello: $model" else ""
                findViewById<TextView>(R.id.tvWarranty)?.text = if (warranty.isNotEmpty()) "Garanzia: $warranty" else ""
                
                // Imposta colore di sfondo in base al risultato
                val backgroundColor = if (callerName == "Numero Sconosciuto" || callerName == "Errore ricerca") {
                    0xFFFF6B6B.toInt() // Rosso per sconosciuti
                } else {
                    0xFF4CAF50.toInt() // Verde per clienti trovati
                }
                setBackgroundColor(backgroundColor)
                
                // Chiudi overlay al click
                setOnClickListener {
                    removeOverlay()
                    stopSelf()
                }
            }
            
            // Configura i parametri della finestra
            val params = WindowManager.LayoutParams().apply {
                width = WindowManager.LayoutParams.MATCH_PARENT
                height = WindowManager.LayoutParams.WRAP_CONTENT
                type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                } else {
                    @Suppress("DEPRECATION")
                    WindowManager.LayoutParams.TYPE_PHONE
                }
                flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                        WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                format = PixelFormat.TRANSLUCENT
                gravity = Gravity.TOP
                y = 100 // Margine dal top
            }
            
            // Aggiungi la view al WindowManager
            windowManager?.addView(overlayView, params)
            Log.d("OverlayService", "Overlay mostrato con successo")
            
        } catch (e: Exception) {
            Log.e("OverlayService", "Errore mostrando overlay: ${e.message}", e)
        }
    }
    
    private fun removeOverlay() {
        try {
            overlayView?.let {
                windowManager?.removeView(it)
                overlayView = null
                Log.d("OverlayService", "Overlay rimosso")
            }
        } catch (e: Exception) {
            Log.e("OverlayService", "Errore rimozione overlay: ${e.message}")
        }
    }
    
    override fun onDestroy() {
        super.onDestroy()
        removeOverlay()
        Log.d("OverlayService", "Servizio Overlay distrutto")
    }
    
    override fun onBind(intent: Intent?): IBinder? = null
}