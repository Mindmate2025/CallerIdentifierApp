package com.calleridentifier.service

import android.content.Context
import android.util.Log
import com.calleridentifier.database.AppDatabase
import com.calleridentifier.database.ClienteLocalEntity
import com.calleridentifier.database.toLocalEntity
import com.calleridentifier.supabase.SupabaseService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class HybridClienteService(private val context: Context) {
    
    private val localDb = AppDatabase.getDatabase(context)
    private val supabaseService = SupabaseService()
    
    /**
     * Ricerca IBRIDA: prima locale (veloce), poi online se necessario
     */
    suspend fun findClienteByTelefono(telefono: String): ClienteLocalEntity? {
        return withContext(Dispatchers.IO) {
            try {
                val numeroTelefono = pulisciNumero(telefono)
                Log.d("HybridService", "🔍 Ricerca ibrida per: $numeroTelefono")
                
                // STEP 1: Cerca nel database LOCALE (veloce)
                val clienteLocale = localDb.clienteDao().findByPhoneNumber(numeroTelefono)
                
                if (clienteLocale != null) {
                    Log.d("HybridService", "✅ LOCALE: Cliente trovato: ${clienteLocale.nome}")
                    return@withContext clienteLocale
                }
                
                Log.d("HybridService", "⚠️ NON trovato nel database locale")
                
                // STEP 2: Cerca ONLINE (più lento)
                Log.d("HybridService", "🌐 Ricerca online...")
                val clienteSupabase = supabaseService.findClienteByTelefono(telefono)
                
                if (clienteSupabase != null) {
                    Log.d("HybridService", "✅ ONLINE: Cliente trovato: ${clienteSupabase.nome}")
                    
                    // STEP 3: Salva in locale per la prossima volta
                    val clienteLocaleNuovo = clienteSupabase.toLocalEntity()
                    localDb.clienteDao().insertCliente(clienteLocaleNuovo)
                    Log.d("HybridService", "💾 Cliente salvato in locale per il futuro")
                    
                    return@withContext clienteLocaleNuovo
                }
                
                Log.d("HybridService", "❌ Cliente NON trovato né locale né online")
                null
                
            } catch (e: Exception) {
                Log.e("HybridService", "Errore ricerca ibrida: ${e.message}", e)
                null
            }
        }
    }
    
    /**
     * Sincronizzazione completa da Supabase a database locale
     */
    suspend fun syncFromSupabase(): SyncResult {
        return withContext(Dispatchers.IO) {
            try {
                Log.d("HybridService", "🔄 Inizio sincronizzazione completa...")
                
                // Scarica tutti i clienti da Supabase
                val clientiSupabase = supabaseService.getAllClienti()
                
                if (clientiSupabase.isEmpty()) {
                    Log.w("HybridService", "⚠️ Nessun cliente ricevuto da Supabase")
                    return@withContext SyncResult.Error("Nessun dato ricevuto da Supabase")
                }
                
                Log.d("HybridService", "📥 Ricevuti ${clientiSupabase.size} clienti da Supabase")
                
                // Converti in entità locali
                val clientiLocali = clientiSupabase.mapNotNull { supabaseCliente ->
                    try {
                        supabaseCliente.toLocalEntity()
                    } catch (e: Exception) {
                        Log.w("HybridService", "Errore conversione cliente ${supabaseCliente.id}: ${e.message}")
                        null
                    }
                }
                
                // Cancella e inserisci tutto (sincronizzazione completa)
                localDb.clienteDao().deleteAll()
                localDb.clienteDao().insertAllClienti(clientiLocali)
                
                val finalCount = localDb.clienteDao().getClientCount()
                Log.d("HybridService", "✅ Sincronizzazione completata: $finalCount clienti salvati")
                
                SyncResult.Success(finalCount)
                
            } catch (e: Exception) {
                Log.e("HybridService", "❌ Errore sincronizzazione: ${e.message}", e)
                SyncResult.Error(e.message ?: "Errore sconosciuto")
            }
        }
    }
    
    /**
     * Stato del database locale
     */
    suspend fun getLocalDatabaseInfo(): DatabaseInfo {
        return withContext(Dispatchers.IO) {
            try {
                val clientCount = localDb.clienteDao().getClientCount()
                val lastSync = localDb.clienteDao().getLastSyncTime() ?: 0L
                
                DatabaseInfo(clientCount, lastSync)
            } catch (e: Exception) {
                Log.e("HybridService", "Errore lettura info database: ${e.message}")
                DatabaseInfo(0, 0L)
            }
        }
    }
    
    /**
     * Test connessioni
     */
    suspend fun testConnections(): ConnectionStatus {
        return withContext(Dispatchers.IO) {
            val localCount = try {
                localDb.clienteDao().getClientCount()
            } catch (e: Exception) {
                -1
            }
            
            val supabaseOk = try {
                supabaseService.testConnection()
            } catch (e: Exception) {
                false
            }
            
            ConnectionStatus(localCount, supabaseOk)
        }
    }
    
    private fun pulisciNumero(numero: String): String {
        return numero.replace("+", "")
            .replace(" ", "")
            .replace("-", "")
            .replace("(", "")
            .replace(")", "")
    }
}

// Classi di supporto
sealed class SyncResult {
    data class Success(val clientCount: Int) : SyncResult()
    data class Error(val message: String) : SyncResult()
}

data class DatabaseInfo(
    val localClientCount: Int,
    val lastSyncTimestamp: Long
)

data class ConnectionStatus(
    val localClientCount: Int,
    val supabaseConnected: Boolean
)