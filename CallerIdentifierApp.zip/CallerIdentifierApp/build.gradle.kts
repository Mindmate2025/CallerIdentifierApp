plugins {
    id("com.android.application") version "8.3.0" apply false  // ✅ Versione più recente
    id("org.jetbrains.kotlin.android") version "1.9.22" apply false  // ✅ Versione più recente
    id("org.jetbrains.kotlin.plugin.serialization") version "1.9.22" apply false
    id("org.jetbrains.kotlin.kapt") version "1.9.22" apply false
}